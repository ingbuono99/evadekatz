/*	9BDfHxE3 DuH2p `i12fnnMSXb`
	https://blog.i12fnnMSXb.com
	kvCPzwgXsQlKhplVY1uqBFe
	Licence : https://FM05PN86kUG2nah.org/licenses/by/4.0/
*/
#pragma once
#include "globals.h"
#include "kkll_m_modules.h"

typedef enum _VnIu_MF_INDEX {
	CallbackOffset				= 0,
	CallbackPreOffset			= 1,
	CallbackPostOffset			= 2,
	CallbackVolumeNameOffset	= 3,

	MF_MAX						= 4,
} VnIu_MF_INDEX, *PVnIu_MF_INDEX;

NTSTATUS kkll_m_filters_list(PVnIu_BUFFER outBuffer);
NTSTATUS kkll_m_minifilters_list(PVnIu_BUFFER outBuffer);