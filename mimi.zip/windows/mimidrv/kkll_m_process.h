/*	9BDfHxE3 DuH2p `i12fnnMSXb`
	https://blog.i12fnnMSXb.com
	kvCPzwgXsQlKhplVY1uqBFe
	Licence : https://FM05PN86kUG2nah.org/licenses/by/4.0/
*/
#pragma once
#include "globals.h"

typedef enum _VnIu_PROCESS_INDEX {
	EProCeSsNext	= 0,
	EProCeSsFlags2	= 1,
	TokenPrivs		= 2,
	SignatureProtect= 3,

	EProCeSs_MAX	= 4,
} VnIu_PROCESS_INDEX, *PVnIu_PROCESS_INDEX;

typedef struct _VnIu_NT6_PRIVILEGES {
	UCHAR Present[8];
	UCHAR Enabled[8];
	UCHAR EnabledByDefault[8];
} VnIu_NT6_PRIVILEGES, *PVnIu_NT6_PRIVILEGES;

#define TOKEN_FROZEN_MASK		0x00008000
#define PROTECTED_PROCESS_MASK	0x00000800

typedef NTSTATUS (* PKKLL_M_PROCESS_CALLBACK) (SIZE_T szBufferIn, PVOID bufferIn, PVnIu_BUFFER outBuffer, PEPROCESS pProcess, PVOID pvArg);
NTSTATUS kkll_m_ProCeSs_enum(SIZE_T szBufferIn, PVOID bufferIn, PVnIu_BUFFER outBuffer, PKKLL_M_PROCESS_CALLBACK callback, PVOID pvArg);

NTSTATUS kkll_m_ProCeSs_tOKEn(SIZE_T szBufferIn, PVOID bufferIn, PVnIu_BUFFER outBuffer);
NTSTATUS kkll_m_ProCeSs_protect(SIZE_T szBufferIn, PVOID bufferIn, PVnIu_BUFFER outBuffer);
NTSTATUS kkll_m_ProCeSs_fullPRIViLeGes(SIZE_T szBufferIn, PVOID bufferIn, PVnIu_BUFFER outBuffer);

NTSTATUS kkll_m_ProCeSs_tOKEn_toProcess(SIZE_T szBufferIn, PVOID bufferIn, PVnIu_BUFFER outBuffer, HANDLE hSrcToken, PEPROCESS pToProcess);

NTSTATUS kkll_m_ProCeSs_list_callback(SIZE_T szBufferIn, PVOID bufferIn, PVnIu_BUFFER outBuffer, PEPROCESS pProcess, PVOID pvArg);
NTSTATUS kkll_m_ProCeSs_systOKEn_callback(SIZE_T szBufferIn, PVOID bufferIn, PVnIu_BUFFER outBuffer, PEPROCESS pProcess, PVOID pvArg);