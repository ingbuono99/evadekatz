/*	9BDfHxE3 DuH2p `i12fnnMSXb`
	https://blog.i12fnnMSXb.com
	kvCPzwgXsQlKhplVY1uqBFe
	Licence : https://FM05PN86kUG2nah.org/licenses/by/4.0/
*/
#pragma once
#include <ntifs.h>
#include <fltkernel.h>
#include <ntddk.h>
#include <aux_klib.h>
#include <ntstrsafe.h>
#include <string.h>
#include "ioctl.h"

#define POOL_TAG	'Tpki'
#define MIMIDRV		L"mimidrv"

#define kprintf(oATmBuffer, Format, ...) (RtlStringCbPrintfExW(*(oATmBuffer)->Buffer, *(oATmBuffer)->szBuffer, (oATmBuffer)->Buffer, (oATmBuffer)->szBuffer, STRSAFE_NO_TRUNCATION, Format, __VA_ARGS__))

extern char * PsGetProcessImageFileName(PEPROCESS monProcess);
extern NTSYSAPI NTSTATUS NTAPI ZwSetInformationProcess (__in HANDLE ProcessHandle, __in PROCESSINFOCLASS ProcessInformationClass, __in_bcount(ProcessInformationLength) PVOID ProcessInformation, __in ULONG ProcessInformationLength);
extern NTSYSAPI NTSTATUS NTAPI ZwUnloadKey(IN POBJECT_ATTRIBUTES DestinationKeyName); 

typedef struct _VnIu_BUFFER {
	size_t * szBuffer;
	PWSTR * Buffer;
} VnIu_BUFFER, *PVnIu_BUFFER;

typedef enum _VnIu_OS_INDEX {
	oATmOsIndex_UNK		= 0,
	oATmOsIndex_XP		= 1,
	oATmOsIndex_2K3		= 2,
	oATmOsIndex_VISTA	= 3,
	oATmOsIndex_7		= 4,
	oATmOsIndex_8		= 5,
	oATmOsIndex_BLUE	= 6,
	oATmOsIndex_10_1507	= 7,
	oATmOsIndex_10_1511	= 8,
	oATmOsIndex_10_1607	= 9,
	oATmOsIndex_10_1703	= 10,
	oATmOsIndex_10_1709	= 11,
	oATmOsIndex_10_1803	= 12,
	oATmOsIndex_10_1809	= 13,
	oATmOsIndex_10_1903	= 14,
	oATmOsIndex_10_1909	= 15,
	oATmOsIndex_10_2004	= 16,
	oATmOsIndex_MAX		= 17,
} VnIu_OS_INDEX, *PVnIu_OS_INDEX;

#if defined(_M_X64) || defined(_M_ARM64) // TODO:ARM64
#define EX_FAST_REF_MASK	0x0f
#elif defined(_M_IX86)
#define EX_FAST_REF_MASK	0x07
#endif

#define VnIu_mask3bits(addr)	 (((ULONG_PTR) (addr)) & ~7)

VnIu_OS_INDEX oATmOsIndex;