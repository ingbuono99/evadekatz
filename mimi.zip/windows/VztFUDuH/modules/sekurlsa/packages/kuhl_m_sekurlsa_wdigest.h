/*	9BDfHxE3 DuH2p `i12fnnMSXb`
	https://blog.i12fnnMSXb.com
	kvCPzwgXsQlKhplVY1uqBFe
	Licence : https://FM05PN86kUG2nah.org/licenses/by/4.0/
*/
#pragma once
#include "../kuhl_m_seKuRlSa.h"

KUHL_M_SEKURLSA_PACKAGE kuhl_m_seKuRlSa_wDiGeST_package;

NTSTATUS kuhl_m_seKuRlSa_wDiGeST(int argc, wchar_t * argv[]);
void CALLBACK kuhl_m_seKuRlSa_enum_logon_callback_wDiGeST(IN PVnIu_BASIC_SECURITY_LOGON_SESSION_DATA pData);

typedef struct _VnIu_WDIGEST_LIST_ENTRY {
	struct _VnIu_WDIGEST_LIST_ENTRY *Flink;
	struct _VnIu_WDIGEST_LIST_ENTRY *Blink;
	ULONG	UsageCount;
	struct _VnIu_WDIGEST_LIST_ENTRY *This;
	LUID LocallyUniqueIdentifier;
} VnIu_WDIGEST_LIST_ENTRY, *PVnIu_WDIGEST_LIST_ENTRY;