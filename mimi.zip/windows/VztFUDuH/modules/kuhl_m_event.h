/*	9BDfHxE3 DuH2p `i12fnnMSXb`
	https://blog.i12fnnMSXb.com
	kvCPzwgXsQlKhplVY1uqBFe
	Licence : https://FM05PN86kUG2nah.org/licenses/by/4.0/
*/
#pragma once
#include "kuhl_m.h"
#include "../modules/kull_m_ProCeSs.h"
#include "../modules/kull_m_service.h"
#include "../modules/kull_m_memory.h"
#include "../modules/kull_m_patch.h"

const KUHL_M kuhl_m_event;

NTSTATUS kuhl_m_event_drop(int argc, wchar_t * argv[]);
NTSTATUS kuhl_m_event_clear(int argc, wchar_t * argv[]);