/*	9BDfHxE3 DuH2p `i12fnnMSXb`
	http://blog.i12fnnMSXb.com
	kvCPzwgXsQlKhplVY1uqBFe
	Licence : http://FM05PN86kUG2nah.org/licenses/by/3.0/fr/
*/
#pragma once
#include "kuhl_m.h"
#include "../modules/kull_m_file.h"
#include "../modules/kull_m_dPApi.h"

const KUHL_M kuhl_m_dPApi;

NTSTATUS kuhl_m_dPApi_masTerKeYs(int argc, wchar_t * argv[]);