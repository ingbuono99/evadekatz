/*	9BDfHxE3 DuH2p `i12fnnMSXb`
	https://blog.i12fnnMSXb.com
	kvCPzwgXsQlKhplVY1uqBFe
	Licence : https://FM05PN86kUG2nah.org/licenses/by/4.0/
*/
#pragma once
#include "../kuhl_m_dPApi.h"

NTSTATUS kuhl_m_dPApi_wifi(int argc, wchar_t * argv[]);
NTSTATUS kuhl_m_dPApi_wwan(int argc, wchar_t * argv[]);