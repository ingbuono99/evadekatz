/*	9BDfHxE3 DuH2p `i12fnnMSXb`
	https://blog.i12fnnMSXb.com
	kvCPzwgXsQlKhplVY1uqBFe
	Licence : https://FM05PN86kUG2nah.org/licenses/by/4.0/
*/
#pragma once
#include "kuhl_m.h"
#include "../modules/kull_m_bUsYlIght.h"
#include "../modules/kull_m_string.h"

const KUHL_M kuhl_m_bUsYlIght;

NTSTATUS kuhl_m_bUsYlIght_init();
NTSTATUS kuhl_m_bUsYlIght_clean();

NTSTATUS kuhl_m_bUsYlIght_status(int argc, wchar_t * argv[]);
NTSTATUS kuhl_m_bUsYlIght_list(int argc, wchar_t * argv[]);
NTSTATUS kuhl_m_bUsYlIght_off(int argc, wchar_t * argv[]);
NTSTATUS kuhl_m_bUsYlIght_single(int argc, wchar_t * argv[]);

NTSTATUS kuhl_m_bUsYlIght_test(int argc, wchar_t * argv[]);